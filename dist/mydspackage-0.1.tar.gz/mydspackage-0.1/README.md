# mydspackage
This library is the my first Python package and it contains useful
sorting and recursion functions.

## Building this package locally
`python setup.py sdist`

## Installing this package from Github
`pip install git+https://github.com/jmsimang/mydspackage.git`

## Updating this package from Github
`pip install --upgrade git+https://github.com/jmsimang/mydspackage.git`
